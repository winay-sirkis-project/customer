package indil.customer

import io.flutter.embedding.android.FlutterFragmentActivity;
import io.flutter.embedding.android.FlutterActivity;

class MainActivity: FlutterFragmentActivity() {
}
